# prox

## Install
```
pip install --user prox
```

## Usage
- Set Proxy up (Per User)
```
prox proxy=
```
- Turn off Proxy
```
prox off 
```
- Turn on Proxy
```
prox off 
```
- Auto toggle proxy
```
prox
```

## TODO
- Installers for osx,win,gnome,kde

